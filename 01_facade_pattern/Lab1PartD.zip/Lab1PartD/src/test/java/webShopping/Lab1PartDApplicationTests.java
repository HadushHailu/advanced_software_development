package webShopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab1PartDApplicationTests {

	@Test
	void contextLoads() {
	}

}
