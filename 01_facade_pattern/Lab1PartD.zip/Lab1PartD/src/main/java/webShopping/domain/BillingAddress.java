package webShopping.domain;

public class BillingAddress extends Address{
}
