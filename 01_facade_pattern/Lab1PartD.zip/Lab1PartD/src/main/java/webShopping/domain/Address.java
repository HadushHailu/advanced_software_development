package webShopping.domain;

public class Address {
    private String street;
    private String city;
    private String zip;
}
