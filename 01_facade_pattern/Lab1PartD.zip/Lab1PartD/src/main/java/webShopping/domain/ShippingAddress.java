package webShopping.domain;

public class ShippingAddress extends Address{
}
