package automatic_gate;

public enum States {
    OPENING, CLOSING, OPEN, CLOSED, STANDSTILL;
}
