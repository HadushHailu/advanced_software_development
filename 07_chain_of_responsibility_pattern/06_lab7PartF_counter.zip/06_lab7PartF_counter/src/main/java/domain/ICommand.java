package domain;

public interface ICommand {
    void execute();
    void unExecute();
}
