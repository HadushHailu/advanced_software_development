package domain;

public interface ICountForFramesObserver {
public void update(int count);
public void setVisible(boolean set);
}
