package domain;

public interface ICountFroLoggersObserver {
    public void update(int count);
}
