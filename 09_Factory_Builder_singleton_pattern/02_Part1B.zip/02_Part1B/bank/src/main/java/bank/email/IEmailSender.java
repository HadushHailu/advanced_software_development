package bank.email;

public interface IEmailSender {
    public void send(String message);
}
