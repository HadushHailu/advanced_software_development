package counter;

public interface ICountObserver {
public void setCount(int count);
public void setVisible(boolean set);
}
