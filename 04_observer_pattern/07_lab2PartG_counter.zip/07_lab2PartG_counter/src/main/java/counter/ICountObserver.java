package counter;

public interface ICountObserver {
public void update(int count);
public void setCount(int count);
public void setVisible(boolean set);
}
