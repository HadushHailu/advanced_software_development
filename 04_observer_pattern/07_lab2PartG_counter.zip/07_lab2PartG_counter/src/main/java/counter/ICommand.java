package counter;

public interface ICommand {
    void execute();
    void unExecute();
}
