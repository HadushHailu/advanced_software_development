package automatic_gate;

public enum States {
    OPENING, CLOSING, OPEN, CLOSE;
}
