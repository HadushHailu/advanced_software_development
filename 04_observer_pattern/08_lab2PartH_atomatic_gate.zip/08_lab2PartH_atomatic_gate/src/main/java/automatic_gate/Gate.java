package automatic_gate;

public class Gate {
    public void open(){
        System.out.println("Open command sent");
    }

    public void close(){
        System.out.println("Close command sent");
    }

    public void stop(){
        System.out.println("Stop command sent");
    }
}
