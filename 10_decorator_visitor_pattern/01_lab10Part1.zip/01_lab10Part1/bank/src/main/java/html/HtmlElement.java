package html;

public interface HtmlElement {
    String toHtml();
}
