package bank.domain;

public interface CheckingInterestStrategy{
    public double getRate();
}
