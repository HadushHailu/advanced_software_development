package bank.domain;

public interface SavingInterestStrategy {
    public double getRate();
}
