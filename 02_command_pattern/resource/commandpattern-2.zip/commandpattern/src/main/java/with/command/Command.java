package with.command;

public interface Command {
	void execute();
	void unExecute();
}
