package customer.dao;

import customer.domain.Customer;

public interface ICustomerDAO {
    public void save(Customer customer);
}
