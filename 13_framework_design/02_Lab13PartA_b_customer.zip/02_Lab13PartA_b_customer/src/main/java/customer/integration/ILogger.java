package customer.integration;

import org.springframework.stereotype.Component;


public interface ILogger {
    public void log(String message);
}
