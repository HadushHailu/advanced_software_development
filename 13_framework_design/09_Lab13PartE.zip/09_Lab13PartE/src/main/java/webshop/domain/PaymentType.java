package webshop.domain;

public interface PaymentType {
}
