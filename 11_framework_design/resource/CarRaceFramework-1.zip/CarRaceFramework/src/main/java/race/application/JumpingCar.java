package race.application;

import race.framework.Car;

public class JumpingCar extends Car {
    public void jump(){
        System.out.println("******JUMP*******");
    }
}
