package race.framework;

public interface Observer {
	public void update(int speed);
}
