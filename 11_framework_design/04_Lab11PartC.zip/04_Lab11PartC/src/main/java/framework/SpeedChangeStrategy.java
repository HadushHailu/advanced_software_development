package framework;

public abstract class SpeedChangeStrategy {
    abstract int compute(double speed);
}
