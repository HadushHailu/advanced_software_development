package framework;

public interface Observers {
    void update(double speed);
}
