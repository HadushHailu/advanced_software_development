package framework;

public class Observable {

}
