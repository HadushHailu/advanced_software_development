package framework;

public class CarActionDispatcher {
    public void action(String action){

    }
}
